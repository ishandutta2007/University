/*
Something Tasteless

1.素数个数估算
  设PI(x) 为小于 x 的素数的个数
  当 x 足够大时，PI(x) = x/lnx;
2.n! 的素因子分解中的素数 p 的次数 为
  [n/p] + [n/(p^2)] + [n/(p^3)] + ... +


*/
